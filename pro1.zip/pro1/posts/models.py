from django.db import models

# Create your models here.
from datetime import date

class Mypost(models.Model):
    title =models.CharField(max_length=100)
    desc =models.TextField()
    date =models.DateField(default=date.today)
    image= models.ImageField(upload_to='uploads', default='a.jpg')

