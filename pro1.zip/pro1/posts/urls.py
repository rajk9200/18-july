from django.urls import path
# from .views import showall
from . import views
urlpatterns = [
    path('', views.showall),
]
