from django.shortcuts import render

# Create your views here.
from .models import Mypost

def showall(request):
    posts=Mypost.objects.all()

    all_post={
        'posts':posts
    }

    return render(request,'showall.html',all_post)